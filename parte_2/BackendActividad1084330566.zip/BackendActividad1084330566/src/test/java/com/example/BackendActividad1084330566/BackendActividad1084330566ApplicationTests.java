package com.example.BackendActividad1084330566;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendActividad1084330566ApplicationTests {

	@Test
	void contextLoads() {
	}

}
